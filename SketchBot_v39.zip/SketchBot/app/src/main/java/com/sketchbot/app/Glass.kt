package com.sketchbot.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.widget.LinearLayout

/**
 * بطاقة زجاج سائل (بدون حركة): خلفية دافئة داكنة ثابتة + طبقات الزجاج (تلوين، لمعان، حافة مضيئة، تشتت لوني).
 */
class LiquidCardLinear(ctx: Context, private val rDp: Float) : LinearLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val clip = Path()
    private val inner = Path()
    private val rect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    init { setWillNotDraw(false) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        val r = rDp * d
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        val ins = RectF(1.2f * d, 1.2f * d, w - 1.2f * d, h - 1.2f * d)
        inner.reset(); inner.addRoundRect(ins, r - d, r - d, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        if (width == 0 || height == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        c.save()
        c.clipPath(clip)
        // خلفية دافئة ثابتة (توهج برتقالي خافت من الأسفل)
        p.shader = LinearGradient(0f, 0f, 0f, h, Color.parseColor("#0A0403"), Color.parseColor("#2A0D05"), Shader.TileMode.CLAMP)
        c.drawRect(rect, p)
        p.shader = RadialGradient(w * 0.5f, h * 1.05f, w * 0.9f, Color.argb(0x90, 122, 42, 12), Color.argb(0, 122, 42, 12), Shader.TileMode.CLAMP)
        c.drawRect(rect, p)
        // جسم الزجاج: تلوين أبيض خفيف + لمعان علوي
        p.shader = LinearGradient(0f, 0f, 0f, h, Color.argb(0x2A, 255, 255, 255), Color.argb(0x0C, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(rect, p)
        p.shader = LinearGradient(0f, 0f, 0f, h * 0.32f, Color.argb(0x38, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(rect, p)
        p.shader = null
        // حواف بتشتت لوني (أحمر/أزرق)
        rim.shader = null
        rim.strokeWidth = 1.6f * d
        rim.color = Color.argb(0x55, 255, 70, 50)
        c.save(); c.translate(0.9f * d, 0f); c.drawPath(inner, rim); c.restore()
        rim.color = Color.argb(0x55, 60, 120, 255)
        c.save(); c.translate(-0.9f * d, 0f); c.drawPath(inner, rim); c.restore()
        // خط الحافة المضيء: ساطع في الأعلى وخافت في الأسفل
        rim.strokeWidth = 1.2f * d
        rim.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.argb(0xE6, 255, 255, 255), Color.argb(0x40, 255, 255, 255), Color.argb(0x2A, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawPath(inner, rim)
        rim.shader = null
        c.restore()
    }
}

/** خلفية زر زجاجي (شفاف أبيض 7% أو برتقالي 34% للزر الأساسي) مع لمعان علوي وحافة */
class GlassBtnDrawable(private val rDp: Float, private val d: Float, private val primary: Boolean) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gl = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d }
    private val rect = RectF()
    private val path = Path()

    override fun onBoundsChange(b: android.graphics.Rect) {
        rect.set(b.left + 0.5f * d, b.top + 0.5f * d, b.right - 0.5f * d, b.bottom - 0.5f * d)
        fill.color = if (primary) Color.argb(0x7A, 255, 128, 56) else Color.argb(0x2A, 255, 255, 255)
        gl.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, Color.argb(if (primary) 0x55 else 0x38, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        ln.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, Color.argb(0xC0, 255, 255, 255), Color.argb(0x30, 255, 255, 255), Shader.TileMode.CLAMP)
        path.reset()
        val r = rDp * d
        path.addRoundRect(rect, r, r, Path.Direction.CW)
    }

    override fun draw(c: Canvas) {
        c.drawPath(path, fill)
        c.drawPath(path, gl)
        c.drawPath(path, ln)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
