package com.sketchbot.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/** سائل لزج يخرج من نقطة الضغط بأذرع متلوّية ويلتهم الشاشة كلها (يُستعمل عند تبديل الوضع الداكن/الفاتح) */
class VenomView(
    ctx: Context,
    private val cx: Float,
    private val cy: Float,
    private val color: Int,
    private val rim: Int,
    private val onCovered: () -> Unit
) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private var t = 0f
    private var maxR = 1f
    private val n = 140
    private val ta = FloatArray(10)
    private val ts = FloatArray(10)
    private val tl = FloatArray(10)
    private val td = FloatArray(10)

    init {
        isClickable = true
        val rnd = java.util.Random(23)
        for (i in 0 until 10) {
            ta[i] = (i * 2f * PI.toFloat() / 10f) + (rnd.nextFloat() - 0.5f) * 0.5f
            ts[i] = 0.10f + rnd.nextFloat() * 0.12f
            tl[i] = 0.28f + rnd.nextFloat() * 0.4f
            td[i] = rnd.nextFloat() * 0.25f
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        maxR = max(max(hypot(cx, cy), hypot(w - cx, cy)), max(hypot(cx, h - cy), hypot(w - cx, h - cy)))
        val va = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1250
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { onCovered() }
            })
        }
        va.start()
    }

    private fun ease(x: Float): Float = x * x * (3f - 2f * x)

    private fun blob(scale: Float, ph: Float) {
        val e = ease(t)
        val base = maxR * 1.12f * e * scale
        path.reset()
        for (i in 0..n) {
            val th = i * 2f * PI.toFloat() / n
            var r = base * (1f + 0.07f * (1f - 0.7f * t) * (sin(5f * th + ph + t * 7f) + 0.6f * sin(9f * th - ph * 1.3f - t * 9f)))
            for (k in 0 until 10) {
                var dl = th - ta[k]
                while (dl > PI) dl -= (2 * PI).toFloat()
                while (dl < -PI) dl += (2 * PI).toFloat()
                val grow = ((t - td[k]) * 2.2f).coerceIn(0f, 1f)
                val life = if (t < 0.85f) 1f else (1f - (t - 0.85f) / 0.15f)
                val bump = tl[k] * exp(-(dl / ts[k]) * (dl / ts[k])) * grow * life
                r += base * bump * (0.8f + 0.2f * sin(t * 11f + k))
            }
            val x = cx + r * cos(th)
            val y = cy + r * sin(th)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    override fun onDraw(c: Canvas) {
        if (t <= 0.002f) return
        blob(1f, 0f)
        fill.color = rim
        c.drawPath(path, fill)
        blob(0.955f, 1.7f)
        fill.color = color
        c.drawPath(path, fill)
    }
}
