package com.sketchbot.app

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * خلفية "دخان" متحركة (نفس شيدر Smoky Button): أزرق عميق + بني + أسود، تتدفق بحرير.
 * أندرويد 13+: شيدر AGSL مطابق للأصل. الأقدم: بقع ألوان متحركة تقريبية.
 */
class SmokyLinear(
    ctx: Context,
    private val rDp: Float,
    private val pressableOn: Boolean = false,
    private val c1: Int = Color.parseColor("#002FA7"),
    private val c2: Int = Color.parseColor("#5C331F"),
    private val c3: Int = Color.parseColor("#050506")
) : DropLinear(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val clip = Path()
    private val rect = RectF()
    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(0xEE, 5, 5, 6) }
    private val smoke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        color = Color.argb(0x45, 255, 255, 255)
    }
    private var rs: Any? = null
    private val t0 = SystemClock.uptimeMillis()

    init {
        setWillNotDraw(false)
        isClickable = pressableOn
        if (Build.VERSION.SDK_INT >= 33) {
            try { rs = makeShader() } catch (_: Throwable) { rs = null }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean = if (pressableOn) super.onTouchEvent(e) else false

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        clip.reset()
        val r = rDp * d
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
    }

    @TargetApi(33)
    private fun makeShader(): RuntimeShader {
        val s = RuntimeShader(AGSL)
        s.setFloatUniform("uPrimary", Color.red(c1) / 255f, Color.green(c1) / 255f, Color.blue(c1) / 255f)
        s.setFloatUniform("uSecondary", Color.red(c2) / 255f, Color.green(c2) / 255f, Color.blue(c2) / 255f)
        s.setFloatUniform("uShadow", Color.red(c3) / 255f, Color.green(c3) / 255f, Color.blue(c3) / 255f)
        return s
    }

    @TargetApi(33)
    private fun drawAgsl(c: Canvas, t: Float) {
        val s = rs as RuntimeShader
        s.setFloatUniform("uResolution", width.toFloat(), height.toFloat())
        s.setFloatUniform("uTime", t)
        smoke.shader = s
        c.drawRect(rect, smoke)
    }

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        smoke.shader = RadialGradient(x, y, r, Color.argb(0xB0, Color.red(col), Color.green(col), Color.blue(col)),
            Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)), Shader.TileMode.CLAMP)
        c.drawRect(rect, smoke)
    }

    private fun drawFallback(c: Canvas, t: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rr = max(w, h) * 0.75f
        blob(c, w * (0.65f + 0.3f * sin(t * 0.8f)), h * (0.5f + 0.45f * cos(t * 1.1f)), rr, c1)
        blob(c, w * (0.3f + 0.3f * cos(t * 0.6f)), h * (0.5f + 0.45f * sin(t * 0.9f + 1f)), rr * 0.9f, c2)
    }

    override fun onDraw(c: Canvas) {
        if (width == 0 || height == 0) return
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        c.save()
        c.clipPath(clip)
        c.drawRect(rect, base)
        if (rs != null && Build.VERSION.SDK_INT >= 33) {
            try { drawAgsl(c, t) } catch (_: Throwable) { rs = null; smoke.shader = null; drawFallback(c, t) }
        } else drawFallback(c, t)
        c.restore()
        c.drawPath(clip, rim)
        postInvalidateOnAnimation()
    }

    companion object {
        private const val AGSL = """
uniform float2 uResolution;
uniform float uTime;
uniform float3 uPrimary;
uniform float3 uSecondary;
uniform float3 uShadow;

float rnd(float2 p) { return fract(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453); }

float vnoise(float2 p) {
  float2 cell = floor(p);
  float2 o = fract(p);
  float a = rnd(cell);
  float b = rnd(cell + float2(1.0, 0.0));
  float c = rnd(cell + float2(0.0, 1.0));
  float d = rnd(cell + float2(1.0, 1.0));
  float2 bl = o * o * (3.0 - 2.0 * o);
  return mix(a, b, bl.x) + (c - a) * bl.y * (1.0 - bl.x) + (d - b) * bl.x * bl.y;
}

float fbm(float2 p0) {
  float2 p = p0;
  float v = 0.0;
  float amp = 0.5;
  float2x2 rot = float2x2(0.8776, 0.4794, -0.4794, 0.8776);
  for (int i = 0; i < 7; i++) {
    v += amp * vnoise(p);
    p = rot * p * 2.04 + float2(13.7, 9.2);
    amp *= 0.5;
  }
  return v;
}

half4 main(float2 fc) {
  float2 res = uResolution;
  float2 g = float2(fc.x, res.y - fc.y);
  float2 uv = g / res;
  float2 pos = (g - 0.5 * res) / res.y;
  float time = uTime * 0.58;

  float2 silk = pos;
  silk.y += 0.20 * sin(pos.x * 1.55 - time * 1.8) + 0.11 * sin(pos.x * 3.2 + time * 1.35);
  silk.x += 0.06 * sin(pos.y * 4.2 - time * 1.1);

  float2 warp = float2(
    fbm(silk * 1.15 + float2(time * 0.28, -time * 0.17)),
    fbm(silk * 1.05 + float2(4.8, 1.3) - float2(time * 0.18, time * 0.22))
  );
  float2 cur = silk + (warp - 0.5) * 0.82;
  float body = fbm(cur * 1.35 + float2(-time * 0.24, time * 0.14));
  float detail = fbm(cur * 2.7 + float2(time * 0.31, -time * 0.27));
  float pPlume = fbm(cur * 1.20 + float2(-time * 0.38, time * 0.18));
  float sPlume = fbm(cur * 1.10 + float2(time * 0.26, -time * 0.32) + float2(7.2, 3.6));
  float shPlume = fbm(cur * 1.45 + float2(-time * 0.18, time * 0.42) + float2(2.4, 8.1));
  float bPlume = fbm(float2(cur.x * 0.92 - time * 0.34, cur.y * 0.76 + time * 0.16) + float2(6.4, 2.3));

  float sharedFlow = cur.y * 6.8 + cur.x * 1.35 + (warp.x - warp.y) * 5.2;
  float crossFlow = cur.y * 5.4 - cur.x * 2.1 + (warp.x + warp.y) * 3.5;
  float pRib = 0.5 + 0.5 * sin(sharedFlow - time * 2.75);
  float sRib = 0.5 + 0.5 * sin(crossFlow + time * 2.35 + 2.1);
  float shRib = 0.5 + 0.5 * sin(sharedFlow * 0.78 - crossFlow * 0.22 - time * 3.25 + 4.2);
  pRib = smoothstep(0.08, 0.92, pRib);
  sRib = smoothstep(0.08, 0.92, sRib);
  shRib = smoothstep(0.12, 0.88, shRib);

  float pW = smoothstep(0.27, 0.76, pPlume + 0.24 * body) * (0.20 + 1.08 * pRib);
  float sW = smoothstep(0.26, 0.74, sPlume + 0.22 * body) * (0.22 + 1.04 * sRib + 0.12 * detail);
  float shW = 0.16 + smoothstep(0.32, 0.80, shPlume + 0.14 * body) * (0.22 + 0.86 * shRib);
  float tot = max(pW + sW + shW, 0.001);
  float3 color = (uPrimary * pW + uSecondary * sW + uShadow * shW) / tot;

  float depth = smoothstep(0.15, 0.88, body * 0.78 + detail * 0.30);
  color *= 0.65 + depth * 0.62;
  float vein = smoothstep(0.46, 0.80, shPlume + 0.10 * body + 0.16 * shRib);
  color = mix(color, uShadow, vein * (0.12 + 0.42 * shRib));

  float sw = 0.5 + 0.5 * sin(sharedFlow * 1.22 - time * 3.2 + detail * 2.0);
  float sheen = pow(sw, 6.0);
  color += mix(uSecondary, uPrimary, pRib) * sheen * (0.10 + 0.16 * depth);

  float bRidge = 0.26 + 0.24 * bPlume + 0.08 * sin(cur.x * 2.35 - time * 2.6 + warp.x * 3.0);
  float bEnv = 1.0 - smoothstep(bRidge, bRidge + 0.24, uv.y);
  float bCloud = smoothstep(0.18, 0.72, bPlume + 0.22 * detail);
  float bMask = bEnv * (0.48 + 0.52 * bCloud);
  float bFlow = 0.5 + 0.5 * sin(cur.x * 2.1 - time * 2.4 + warp.y * 4.0);
  float3 bColor = mix(uPrimary, uSecondary, smoothstep(0.12, 0.88, bFlow));
  float bShadow = smoothstep(0.48, 0.78, shPlume + 0.18 * bPlume);
  bColor = mix(bColor, uShadow, bShadow * 0.72);
  float bSheen = pow(0.5 + 0.5 * sin(bFlow * 5.0 + time * 2.2), 5.0);
  bColor += mix(uSecondary, uPrimary, bFlow) * bSheen * 0.12;
  color = mix(color, bColor, bMask * 0.72);

  float feather = uv.x + 0.12 * (body - 0.5) + 0.08 * (bPlume - 0.5) + 0.04 * sin(cur.y * 3.0 - time * 1.4);
  float a = smoothstep(0.24, 0.72, feather);
  float3 oc = clamp(color, 0.0, 1.0) * a;
  return half4(half3(oc), half(a));
}
"""
    }
}
