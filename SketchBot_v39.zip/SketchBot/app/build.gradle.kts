plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sketchbot.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sketchbot.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 8
        versionName = "5.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
